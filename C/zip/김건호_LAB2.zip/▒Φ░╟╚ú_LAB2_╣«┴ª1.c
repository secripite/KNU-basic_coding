#include<stdio.h>

int main(void) {
	printf("     *\n    ***\n   *****\n***********\n *********\n  *******\n *********\n***********\n   *****\n    ***\n     *\n");
}